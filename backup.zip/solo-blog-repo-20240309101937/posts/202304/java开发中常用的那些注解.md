title: java开发中常用的那些注解
date: '2023-04-13 11:56:12'
updated: '2023-04-13 11:56:12'
tags: [java, springboot]
permalink: /articles/2023/04/13/1681358172194.html
---
![](https://b3logfile.com/bing/20220503.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## Jackson

文档：https://www.imangodoc.com/38908.html

