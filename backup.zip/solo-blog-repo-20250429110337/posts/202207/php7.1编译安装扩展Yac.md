title: php7.1编译安装扩展Yac
date: '2022-07-13 10:57:56'
updated: '2022-07-13 11:06:43'
tags: [Yac, PHP, 扩展]
permalink: /articles/2022/07/13/1657681076161.html
---
![](https://b3logfile.com/bing/20180209.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

#### 下载Yac库

```sh
wget https://github.com/laruence/yac.git
#或者
git clone https://github.com/laruence/yac.git
```

#### 编译安装

```sh
cd yac
phpize
./configure --with-php-config=/opt/homebrew/opt/php@7.1/bin/php-config 
make
make install
```

- `/opt/homebrew/opt/php@7.1` 是要替换成你自己机器上PHP的安装目录
- `make install` 之后会返回yac.so所在的目录，同一台机器的php扩展一般都会在这个目录下

#### 修改php.ini文件

```
extension=yac.so
```

- 如果你是第一次安装PHP的扩展，那可能改需要修改`extension_dir`的指向目录，这个目录也就是上面`make install` 之后会返回的目录，不然会报找不到yac.so文件，例如：
  ```
  extension_dir = "/opt/homebrew/lib/php/pecl/20160303"
  ```



- 可以通过`php -i | grep ini` 找到php.ini的路径
- 只添加扩展还是无法使用Yac的，还需要增加一些配置

#### 启用Yac

还是在php.ini文件中增加yac的一些配置，可以根据自己的需要调整参数

```
[yac]
yac.enable = 1
yac.enable_cli = 1
yac.keys_memory_size=4M
yac.values_memory_size = 64M
```

#### 重启php-fpm

```
service php-fpm reload
```

#### 查看PHP安装过的扩展

```
php -m
```

![image.png](https://b3logfile.com/file/2022/07/image-7b6f8c18.png)

![image.png](https://b3logfile.com/file/2022/07/image-b1ac9acb.png)

查看到yac，说明扩展安装成功，可以在代码中使用了。

