title: 配置MySQL数据库主从同步
date: '2020-11-18 18:10:34'
updated: '2021-01-06 14:37:20'
tags: [mysql]
permalink: /articles/2020/11/18/1605694234803.html
---
![](https://b3logfile.com/bing/20180327.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 写在前面

1. 环境和工具：windows系统、mysql-5.7.26（主、从）、Navicat Premium
2. 主库（master）：10.1.100.93；从库（slave）：10.1.100.94
3. 最好保持主从数据库版本一致

## 配置主库

1. 打开主库的配置文件my.ini(不同于linux环境下的my.cnf)，该文件在在mysql的安装目录下。我的是`C:\*****\bin\mysql\mysql5.7.26\my.ini`。在`my.ini`的最下面可以看到`[mysqld]`，在它下面添加主库的配置
   所以
   
   ```
   [mysqld]
   default_authentication_plugin=mysql_native_password
   port = 3306
   #以下是新增配置
   server-id=1 #配置唯一server-id，主库和从库不能重复
   log-bin=mysql-bin #开启二进制日志
   binlog-do-db=test #同步的数据库
   binlog-ignore-db=mysql #不需要同步的数据库
   ```
2. 重启主库mysql
3. 查看主库的server-id以及其他配置信息
   打开Navicat Premium连接到主库，切换到命令行模式（快捷键：F6），分别执行下面的sql语句：
   
   ```
   show variables like 'server_id';
   ```
   
   ```
   show master status;
   ```
   
   ![image.png](https://b3logfile.com/file/2020/11/image-ce8a41f8.png)
4. 为从库创建用于同步的帐号（一般不会使用root帐号）
   我是直接使用Navicat Premium来创建帐号
   用户名：slave
   密码：123456
   并且在服务器权限里选中全部的权限
   ![image.png](https://b3logfile.com/file/2020/11/image-1c59fbce.png)

## 配置从库

1. 打开从库的配置文件`my.ini`，同样在`my.ini`的`[mysqld]`下面添加主库的配置
   
   ```
   [mysqld]
   default_authentication_plugin=mysql_native_password
   port = 3306
   #下面是新加配置
   server-id=2 #和主库不一致
   #master-host=10.1.100.93 #主库ip
   #master-user=slave #主库用户名
   #master-password=123456 #主库密码
   #master-port=3306 #主库端口号
   #master-connect-retry=60
   replicate-do-db=test #需要同步的表
   replicate-ignore-db=mysql #不需要同步的表
   ```
2. 重启从库MySQL
   **注意：** 可以看到配置中我注释了`master-*`这部分的配置，是因为MySQL版本从5.1.7以后开始就不支持“master-*”类似的参数。
   如果不注释这块配置则会导致从库MySQL在重启的时候报错：
   
   ```
   unknown variable 'master-host=10.1.100.93'
   ```
   
   该部分配置已改为执行命令的方式进行配置：
   
   ```
   change master to master_host='110.1.100.93',
   master_port=3306,master_user='slave',
   master_password='123456',
   master_log_file=’mysql-bin.000001’,
   master_log_pos=1437;
   ```
   
   其中`master_log_file`和`master_log_pos`的配置值是在主库中执行下面命令后可以查看：
   
   ```
   show master status;
   ```
3. 启动
   执行命令启动从库同步：
   
   ```
   start slave;
   ```
4. 查看是否成功
   在从库命令行执行（Navicat Premium命令行下执行该命令会报错）：
   
   ```
   show slave status\G
   ```
   
   ![image.png](https://b3logfile.com/file/2020/11/image-dcfe791b.png)
   
   可以看到主从已经成功打通

## 验证是否同步

1. 在主库的`test`库中建表`user`
   
   ```
   CREATE TABLE `user`(
   `id` int(11) NOT NULL AUTO_INCREMENT ,
   `name` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT '用户名' ,
   `age`  int(3) UNSIGNED NOT NULL COMMENT '年龄' , 
   PRIMARY KEY (`id`)
   );
   ```
2. 查看从库
   可以发现从库在没有执行上面的sql语句的情况下，也生成了`user`表：
   ![image.png](https://b3logfile.com/file/2020/11/image-52eb93ff.png)

**同样：在主库中添加数据，也会自动同步到从库**

## 至此MySQL主从同步搭建完成

