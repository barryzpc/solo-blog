title: windows下安装Jenkins
date: '2020-11-23 18:26:12'
updated: '2020-11-23 22:52:36'
tags: [jenkins, windows]
permalink: /articles/2020/11/23/1606127171977.html
---
![](https://b3logfile.com/bing/20181118.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 


## 写在前面

- java-1.8.0
- Jenkins-2.267
- 说明：因为Jenkins是java编写的所以必须要先安装jdk，并且Jenkins目前支持在java[8,11]的版本下运行。我第一次安装的是jdk-15所以就无法运行

## 安装java

我选择的是国内镜像下载jdk，避免还要注册登录oracle帐号和下载速度慢等问题。
国内镜像（华为云）：
https://repo.huaweicloud.com/java/jdk/8u151-b12/
![image.png](https://b3logfile.com/file/2020/11/image-dae5e205.png)

一路下一步，中间选择自己要安装的目录即可。

在cmd中查看java的版本号
![image.png](https://b3logfile.com/file/2020/11/image-84e7f12a.png)

java-1.8.0已安装成功，并且也不用再配置环境变量。

## 安装Jenkins

下载地址：https://www.jenkins.io/download/

![image.png](https://b3logfile.com/file/2020/11/image-2ecd9347.png)

下载完成后是一个`jenkins.msi`的安装文件，直接双击打开，一直`next`即可。

中间可以修改自己想要安装到的目标目录和Jenkins启动的端口号。

我的连接地址是：`http://localhost:8091`

安装完成后，会自动打开浏览器，刚开始浏览器可能会出现无法连接的情况，在当前页面刷新一下即可。等待初始化，会出现下面的页面：
![image.png](https://b3logfile.com/file/2020/11/image-7d98e9f0.png)

找到密码文件，打开复制密码，输入进去,点击`继续`即可。

接下来就是根据自己的需要安装插件：
![image.png](https://b3logfile.com/file/2020/11/image-8fb35195.png)

