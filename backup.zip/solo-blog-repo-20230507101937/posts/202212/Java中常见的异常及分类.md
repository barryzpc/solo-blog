title: Java中常见的异常及分类
date: '2022-12-01 15:49:03'
updated: '2022-12-01 15:50:14'
tags: [java, Exception]
permalink: /articles/2022/12/01/1669880943618.html
---
![](https://b3logfile.com/bing/20181202.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## RuntimeException

![image.png](https://b3logfile.com/file/2022/12/image-QewRHDf.png)

## UncheckedException

![image.png](https://b3logfile.com/file/2022/12/image-zVYItsA.png)

这两种异常都应该去捕获

