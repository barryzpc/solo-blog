title: DDD领域驱动设计相关文章收藏
date: '2022-07-12 10:49:53'
updated: '2023-01-31 11:29:31'
tags: [架构, DDD]
permalink: /articles/2022/07/12/1657594193348.html
---
- [DDD的分层架构设计](https://blog.csdn.net/qq_20952591/article/details/122369966)
- [跨越DDD从理论到工程落地的鸿沟](https://zhuanlan.zhihu.com/p/477476710)
- [DDD应用架构内部分享](https://blog.csdn.net/f80407515/article/details/118910078)
- [DDD架构](https://www.jianshu.com/p/36c76dbaa20c)

