title: PHPStorm菜单快捷操作指南
date: '2021-09-05 22:26:12'
updated: '2021-09-05 22:26:12'
tags: [phpstorm]
permalink: /articles/2021/09/05/1630851971940.html
---
![](https://b3logfile.com/bing/20190725.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# PHPStorm菜单快捷操作指南

## 重点操作

* Add Rectangular Selection on Mouse Drag  鼠标拖动时添加矩形选择
* Clone Caret Above 克隆上面的插入符号
* Clone Caret Below 克隆下面的插入符号
* Move Caret to Code Block End 将插入符号移到代码块结尾
* Move Caret to Code Block Start 将插入符号移到代码块开头
* Delete Line 删除行
* Delete to Line End 删除到行尾
* Delete to Line Start 删除到行开始
* Delete to Word End 删除到字尾
* Delete to Word End in Different "CamelHumps" Mode 在不同的“驼峰”模式下删除到词尾
* Find Usages | Previous Highlighted Usage 查找用法|以前突出显示的用法
* Toggle Case 切换大小写
* Rename... 重命名。。。
* Reformat Code 重新格式化代码
* Override Methods... 重写方法。。。
* Implement Methods... 实现方法。。。
* Generate... 生成。。。
* Back 返回
* Find | Add Selection for Next Occurrence 查找|为下一个事件添加选择
* Go to Line/Column... 转到行/列。。。
* Surround With... 周围有。。。
* Folding | Expand 折叠|展开
* Folding | Expand Recursively 折叠|递归展开
* Folding | Expand All 折叠|全部展开
* Optimize Imports 优化导入
* Move Element Left 向左移动元素
* Move Element Right 向右移动元素
* Move Line Down 下移行
* Move Line Up 上移行
* Copy | Path From Repository Root 从存储库根目录复制|路径

## 编辑器操作

* Add or Remove Caret  添加或删除插入符号
* Backspace  退格
* Move Caret Backward a Paragraph 向后移动插入符号段落
* Move Caret Backward a Paragraph with Selection 将插入符号向后移动选定内容的段落
* Choose Lookup Item 选择查找项
* Choose Lookup Item and Insert Dot 选择查找项并插入点
* Choose Lookup Item Replace 选择查找项替换
* Move Caret to Code Block End with Selection 使用所选内容将插入符号移到代码块结尾
* Move Caret to Code Block Start with Selection 将插入符号移到代码块以选定内容开头
* Complete Current Statement 完成当前报表
* Create Rectangular Selection 创建矩形选择
* Create Rectangular Selection on Mouse Drag 鼠标拖动时创建矩形选择
* Cut Line Backward 向后剪切线
* Cut up to Line End 切割至线端
* Decrease Font Size 减小字体大小
* Delete to Word Start 删除到Word开始
* Delete to Word Start in Different "CamelHumps" Mode 在不同的“驼峰”模式下删除到单词开头
* Down 向下
* Down with Selection 向下选择
* Duplicate Line or Selection 复制行或所选内容
* Duplicate Entire Lines 复制整行
* Enter 进入
* Escape  逃脱
* Focus Gutter (accessibility) 聚焦水槽（无障碍）
* Move Caret Forward a Paragraph 将插入符号前移段落
* Move Caret Forward a Paragraph with Selection 将插入符号前移带选定内容的段落
* Hungry Backspace 饥渴的退格
* Increase Font Size 增大字号
* Join Lines 连接线
* Kill Selected Region 杀死所选区域
* Save to Kill Ring 救命戒指
* Kill to Word End 杀到字尾
* Kill to Word Start 终止到单词开始
* Left 左
* Left with Selection 带选定内容的左侧
* Move Caret to Line End 将插入符号移到行尾
* Move Caret to Line End with Selection 使用所选内容将插入符号移到行尾
* Move Caret to Line Start 将插入符号移到行开始
* Move Caret to Line Start with Selection 将插入符号移到以选定内容开头的行
* Move Caret to Matching Brace 插入符号大括号匹配
* Move Down and Scroll 下移并滚动
* Move Down and Scroll with Selection 下移并滚动选定内容
* Move Caret to Page Bottom 将插入符号移到页底
* Move Caret to Page Bottom with Selection 使用所选内容将插入符号移到页面底部
* Move Caret to Page Top 将插入符号移到页面顶部
* Move Caret to Page Top with Selection 使用所选内容将插入符号移到页首
* Move Up and Scroll 上移并滚动
* Move Up and Scroll with Selection 上移并滚动选定内容
* Move Caret to Next Word 将插入符号移到下一个单词
* Move Caret to Next Word in Different "CamelHumps" Mode 以不同的“驼峰”模式将插入符号移到下一个单词
* Move Caret to Next Word with Selection in Different "CamelHumps" Mode 在不同的“驼峰”模式下，将插入符号移动到下一个单词
* Move Caret to Next Word with Selection 使用所选内容将插入符号移到下一个单词。
* Page Down 向下翻页
* Page Down with Selection 向下翻页选择
* Page Up 向上翻页
* Page Up with Selection 向上翻页选择
* Paste from X clipboard 从X剪贴板粘贴
* Paste without Formatting 不带格式粘贴
* Move Caret to Previous Word 将插入符号移到上一个单词
* Move Caret to Previous Word in Different "CamelHumps" Mode 以不同的“驼峰”模式将插入符号移到前一个单词
* Move Caret to Previous Word with Selection in Different "CamelHumps" Mode 在不同的“驼峰”模式下选择将插入符号移到上一个单词
* Move Caret to Previous Word with Selection 使用所选内容将插入符号移到上一个单词
* Reset Font Size 重置字体大小
* Reverse Lines 反转线
* Right 赖特
* Right with Selection 有选择权
* Scroll to Bottom 滚动到底部
* Scroll Down 向下滚动
* Scroll Down and Move if Necessary 如有必要，向下滚动并移动
* Scroll Left 向左滚动
* Scroll Right 向右滚动
* Scroll to Center 滚动到中心8
* Scroll to Top 滚动到顶部
* Scroll Up 向上滚动
* Scroll Up and Move if Necessary 如有必要，向上滚动并移动
* Select Line at Caret 选择插入符号处的行
* Extend Selection 扩展选定范围
* Show Gutter Icon Tooltip (accessibility) 显示檐槽图标工具提示（辅助功能）
* Sort Lines 排序行
* Split Line 分割线
* Start New Line 开始新行
* Start New Line Before Current 在当前行之前启动新行
* Swap selection boundaries 交换选择边界
* Tab  标签
* Move Caret to Text End 将插入符号移到文本结尾
* Move Caret to Text End with Selection 将插入符号移动到选定内容的文本结尾
* Move Caret to Text Start 将插入符号移到文本开头
* Move Caret to Text Start with Selection 将插入符号移到以选定内容开头的文本
* Toggle Case 切换大小写
* Column Selection Mode 列选择模式
* Toggle Insert/Overwrite 切换插入/覆盖
* Toggle Sticky Selection 切换粘滞选择
* Shrink Selection 缩小选择
* Unindent Line or Selection 取消折线或选定内容
* Up 向上
* Up with Selection 向上选择
* Emacs Tab Emacs选项卡
* Expand Live Template / Emmet Abbreviation 展开Live Template/Emmet缩写
* Fill Paragraph 填充段落
* Focus Editor 焦点编辑器
* Next Parameter 下一个参数
* Next Template Variable or Finish In-Place Refactoring 下一个模板变量或完成就地重构
* Prev Parameter Prev参数
* Previous Template Variable 上一个模板变量

## 编辑 Edit

* Copy | Copy Paths 复制|复制路径
* Copy | Copy as Plain Text Copy |以纯文本形式复制
* Copy | Copy as Rich Text 复制|复制为富文本
* Copy | Copy Reference 副本|副本参考
* Copy | Copy Path... 复制|复制路径。。。
* Copy | Absolute Path 复制|绝对路径
* Copy | Path With Line Number 复制|路径和行号
* Copy | Path From Content Root 从内容根目录复制|路径
* Copy | Path From Source Root 从源根目录复制|路径
* Copy | Path From Repository Root 从存储库根目录复制|路径
* Paste | Paste 粘贴|粘贴
* Paste | Paste from History... 粘贴|从历史中粘贴。。。
* Paste | Paste without Formatting 粘贴|无格式粘贴
* Copy JSON Pointer 复制JSON指针
* Delete 删除
* Find | Find...  查找|查找。。。
* Find | Replace... 查找|替换。。。
* Find | Find Next / Move to Next Occurrence 查找|查找下一个/移动到下一个事件
* Find | Find Previous / Move to Previous Occurrence 查找|查找上一个/移动到上一个事件
* Find | Select All Occurrences 查找|选择所有事件
* Find | Unselect Occurrence 查找|取消选择事件
* Find | In Selection 在选择中查找
* Find | Next Occurrence of the Word at Caret 查找|下一个出现在插入符号处的单词
* Find | Find in Path... 查找|在路径中查找。。。
* Find | Replace in Path... 在路径中查找|替换。。。
* Find | Search Structurally... 查找|从结构上搜索。。。
* Find | Replace Structurally... 查找|替换结构。。。
* Find | Evaluate XPath... 查找|计算XPath。。。
* Find | Find by XPath... Find |通过XPath查找。。。
* Find Usages | Find Usages 查找用法|查找用法
* Find Usages | Find Usages Settings... 查找用法|查找用法设置。。。
* Find Usages | Show Usages 查找用法|显示用法
* Find Usages | Find Usages in File 查找用法|查找文件中的用法
* Find Usages | Highlight Usages in File 查找用法|突出显示文件中的用法
* Find Usages | Next Highlighted Usage 查找用法|下一个突出显示的用法
* Column Selection Mode 列选择模式
* Select All 全选
* Extend Selection 扩展选定范围
* Shrink Selection 缩小选择
* Join Lines 连接线
* Duplicate Line or Selection 复制行或所选内容
* Fill Paragraph 填充段落
* Sort Lines 排序行
* Reverse Lines 反转线
* Indent Selection 缩进所选内容
* Unindent Line or Selection 取消折线或选定内容
* Convert Indents | To Spaces 将缩进|转换为空格

## 代码 Code

* Folding | Collapse 折叠|坍塌
* Folding | Collapse Recursively 折叠|递归折叠
* Folding | Collapse All 折叠|全部折叠
* Folding | Expand All to Level 折叠|全部展开至水平
* Folding | Expand Doc Comments 折叠|展开文档注释
* Folding | Collapse Doc Comments 折叠|折叠文档注释
* Folding | Fold Selection / Remove region 折叠|折叠选择/删除区域
* Folding | Fold Code Block 折叠|折叠代码块
* Comment with Line Comment 带行注释的注释
* Comment with Block Comment 带块注释的注释
* Reformat File... 重新格式化文件。。。
* Auto-Indent Lines 自动缩进行
* Rearrange Code 重新排列代码
* Move Statement Down 下移语句
* Move Statement Up 上移语句
* Inspect Code... 检查代码。。。
* Code Cleanup... 代码清理。。。
* Silent Code Cleanup  无提示代码清理
* Locate Duplicates... 查找重复项。。。
* Detect PSR-0 Namespace Roots 检测PSR-0命名空间根
* Update Copyright... 更新版权

