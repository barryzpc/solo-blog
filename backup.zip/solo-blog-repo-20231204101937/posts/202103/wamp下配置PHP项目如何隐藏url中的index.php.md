title: wamp下配置PHP项目如何隐藏url中的index.php
date: '2021-03-24 16:17:52'
updated: '2021-03-24 16:21:43'
tags: [wamp, PHP]
permalink: /articles/2021/03/24/1616573872192.html
---
![](https://b3logfile.com/bing/20190906.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 写在前面

我们本地使用wamp Server配置虚拟主机的时候，在访问URL的时候总是在domain后面带上入口文件index.php。这导致url多上几个字符串观看上很不舒服，而且拼写url的时候需要多敲几个。

## 如何隐藏url中的入口文件

#### 第一种方法: .htaccess文件

在项目中入口文件的同级目录下建一个.htaccess，文件内容如下：

```
<IfModule mod_rewrite.c>
    Options +FollowSymLinks
    RewriteEngine on
    RewriteCond %{REQUEST_FILENAME} !-d
    RewriteCond %{REQUEST_FILENAME} !-f
#    RewriteRule ^(.*)$ index-dev.php/$1 [QSA,PT,L]
    RewriteRule ^(.*)$ index-dev.php [L,E=PATH_INFO:$1]
</IfModule>
<IfModule mod_deflate.c>
AddOutputFilter DEFLATE html xml php js css text/html text/plain 
</IfModule>
```

#### 第二种方法：修改httpd-vhost.conf

在httpd-vhost.conf文件下配置虚拟主机的时候添加重写规则：

```
<VirtualHost *:80>
  #开启重写
  RewriteEngine on
  #哪些文件路径不定义重写，css和js等文件是放在public路径下，所以在视图文件中以/public开头的url不重写路径（注意'/'需要使用'\’来进行转义）
  RewriteCond $1 !^(index\.php|\/public)
  #重写规则：可以不需要输入index.php来进行访问
  RewriteRule ^(.*)$ /index.php/$1 [QSA,PT,L]
  ServerName dev.api.com
  ServerAlias dev.api.com
  DocumentRoot "D:/projects/api"
  <Directory "D:/projects/api/">
	DirectoryIndex index.php index.html
    Options +Indexes +Includes +FollowSymLinks +MultiViews
    AllowOverride All
    Require all granted
  </Directory>
</VirtualHost>
```

