title: 转：nginx中的 fastcgi_pass为什么有时候是unix:/tmp/php-fpm.sock，有时候是127.0.0.1:9000
date: '2020-11-26 09:44:21'
updated: '2020-11-26 09:49:09'
tags: [转载, PHP, nginx]
permalink: /articles/2020/11/26/1606355061499.html
---
![](https://b3logfile.com/bing/20201018.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

原文地址：http://www.architecy.com/archives/481

## nginx中的 fastcgi_pass为什么有时候是unix:/tmp/php-fpm.sock，有时候是127.0.0.1:9000

这牵扯到了nginx和php的通信模式，上面所列的就是这两种，一种是利用系统本身socket的，一种是利用tcp协议的

### 两种协议有区别

UNIX Domain Socket不经过网络，只是在系统内部进行通信，适用于php和nginx都装在同一台linux服务器上

tcp通信协议的也就是fastcgi_pass模式的既适用于php和nginx都装在同一台linux服务器上，同时又适用于不在同一台服务器上的，一般在同一个局域网中，也就是127.0.0.1的意义了

当然我们在真正的php搭建服务器环境的时候，具体用那种，就要看php-fpm.conf中使用的是哪种了

**tcp方式:**
php-fpm.conf: listen = 127.0.0.1:9000
nginx.conf: fastcgi_pass 127.0.0.1:9000;

**UNIX Domain Socket方式:**
php-fpm.conf: listen = /tmp/php-fpm.sock
nginx.conf: fastcgi_pass unix:/tmp/php-fpm.sock;

在我们真正实例中多数都是装在同一台服务器上，所以选择UNIX Domain Socket是比较合适的选择，因为这样可以避免数据传输经过tcp层造成导致TIME_WAIT连接过多的问题。

### 具体两个传输方式的流程如下

- 1.1 TCP Socket(本地回环127.0.0.1)方式的数据传输:
  
  - Nginx <=> socket <=> TCP/IP <=> socket <=> PHP-FPM
- 1.2 TCP Socket(Nginx和PHP-FPM位于不同服务器)的数据传输:
  
  - Nginx <=> socket <=> TCP/IP <=> 物理层 <=> 路由器 <=> 物理层 <=> TCP/IP <=> socket <=> PHP-FPM
- 2.1 UNIX Domain Socket方式的数据传输:
  
  - Nginx <=> socket <=> PHP-FPM

