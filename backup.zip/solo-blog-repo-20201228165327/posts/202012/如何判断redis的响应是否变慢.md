title: 如何判断redis的响应是否变慢
date: '2020-12-08 09:50:29'
updated: '2020-12-08 09:50:29'
tags: [redis]
permalink: /articles/2020/12/08/1607392229857.html
---
![](https://b3logfile.com/bing/20180201.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 写在前面

`redis`响应的快慢是性能好坏判断的直接体现。

`redis`响应的快慢和它所在的服务器的硬件配置有很大的关系，不同的服务器上的`redis`的响应快慢都是不同的，那么如何判断这台服务器的`redis`的响应是否变慢呢？

那就需要知道这台`redis`服务器的`基线性能`。

## 查看redis服务器的基线性能

`redis.2.8.7`之后的版本中，`redis-cli` 命令提供了`–intrinsic-latency` 选项，可以用来监测和统计测试期间内的最大延迟，那么这个延迟就可以作为`redis` 的`基线性能`参考。测试时长可以通过指定`–intrinsic-latency` 选项的参数来控制（一般情况下`120s`足够监测到最大延迟了）。
执行：

```
redis-cli --intrinsic-latency 120
```

我个人机器上的测试结果如下：

```
# redis-cli --intrinsic-latency 120
Max latency so far: 1 microseconds.
Max latency so far: 14 microseconds.
Max latency so far: 20 microseconds.
Max latency so far: 23 microseconds.
Max latency so far: 92 microseconds.
Max latency so far: 97 microseconds.
Max latency so far: 4947 microseconds.
Max latency so far: 5475 microseconds.

876664269 total runs (avg latency: 0.1369 microseconds / 1368.83 nanoseconds per run).
Worst run took 39998x longer than the average latency.
```

可以看出这台机器的最大延迟`5475`微秒，那么就可以判断这台机器的`基线性能`为`5475`微秒。

可以以此来判断`redis`的响应是否变慢。

> 一般认为运行时延迟达到基线性能的2倍以上则可判定`redis`变慢了。

**说明：** 测试`基线性能`时，最好是登陆到`redis`服务器上执行命令，在客户端上执行命令会有网络延迟的因素，导致`基线性能`不准确。

