title: SpringBoot中使用undertow的accesslog 配置%D 获取耗时不生效问题【最优解】
date: '2023-11-22 10:47:53'
updated: '2023-11-22 10:52:23'
tags: [springboot, undertow]
permalink: /articles/2023/11/22/1700621273810.html
---
![](https://b3logfile.com/bing/20210723.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

> 场景：SpringBoot项目中使用了`undertow`作为web服务，在配置accesslog后发现`%D` 并不能获取访问耗时

#### 刚开始的配置

```yaml
server:
  undertow:
    url-charset: UTF-8
    accesslog:
      enabled: true
      dir: /opt/logs
      file-date-format: .yyyy-MM-dd
      prefix: access
      suffix: .log
      pattern: '%t %a %v %r %s %b "%{i,Referer}" "%{i,User-Agent}" "%{i,X-Forwarded-For}" %D ms'
      rotate: true
```

通过查看文档发现如果需要获取耗时，undertow需要开启 server option的`RECORD_REQUEST_START_TIME`

#### 网上普遍的解决方案：

就是在自动配置类里新建一个Bean，将属性set进去，代码如下：

```java
@Configuration
public class UndertowConfig {
    /**
     * 开启undertow计时
     * @return
     */
    @Bean
    public UndertowServletWebServerFactory undertowServletWebServerFactory() {
        UndertowServletWebServerFactory factory = new UndertowServletWebServerFactory();
        factory.addBuilderCustomizers(new UndertowBuilderCustomizer() {
            @Override
            public void customize(Undertow.Builder builder) {
                builder.setServerOption(UndertowOptions.RECORD_REQUEST_START_TIME, true);
            }
        });
        return factory;
    }
}
```

但这种方法总感觉很奇怪，还要重新new一个新的`UndertowServletWebServerFactory`, 所以我就没有采取这种做法。
感觉这种开关应该是可以通配置来解决的，通过查看源码发现确实是可以的。

#### 通过配置开启【最优解】

通过配置文件开启`undertow`的计时：

```yaml
server:
  undertow:
    url-charset: UTF-8
    options:
      server:
        record-request-start-time: true #记录请求开始时间
    accesslog:
      enabled: true
      dir: /opt/logs
      file-date-format: .yyyy-MM-dd
      prefix: access
      suffix: .log
      pattern: '%t %a %v %r %s %b "%{i,Referer}" "%{i,User-Agent}" "%{i,X-Forwarded-For}" %D ms'
      rotate: true
```

