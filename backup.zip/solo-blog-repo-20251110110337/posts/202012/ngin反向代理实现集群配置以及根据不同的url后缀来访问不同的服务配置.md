title: ngin反向代理实现集群配置以及根据不同的url后缀来访问不同的服务配置
date: '2020-12-04 00:32:22'
updated: '2020-12-04 15:43:54'
tags: [nginx]
permalink: /articles/2020/12/04/1607013142180.html
---
![](https://b3logfile.com/bing/20180109.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 



## 写在前面

- nginx服务器：
  
  ```
  10.1.100.90:80 #使用的是默认端口
  ```
- 集群服务器
  
  ```
  10.1.100.94:8094
  10.1.100.95:8095
  10.1.100.96:8096
  10.1.100.97:8097
  ```
- 说明：nginx服务器为统一对外访问的入口，集群服务器为业务逻辑程序入口。当然也可以使用集群服务器中的一台服务器作为nginx服务器对外访问。这里分开使用，配置方法是一样的。

## nginx集群配置

### 配置前的准备

打开nginx配置文件。我这里是单独建了一个`vhosts`文件夹（`/***/nginx-1.17.1/conf/vhost`），专门用来存放项目的配置文件。但需要在`/***/nginx-1.17.1/conf/nginx.conf`配置文件的末尾添加一句配置才能将`vhosts`下的配置文件引入并生效。
添加的配置：

```
include vhost/*.conf;
```

### 配置集群

新建配置文件`/***/nginx-1.17.1/conf/vhost/10.1.100.90.conf`

文件配置如下：

```
upstream sample { 
	server 10.1.100.94:8094 weight=1;
	server 10.1.100.95:8095 weight=2;
	server 10.1.100.96:8096 weight=2;
	server 10.1.100.97:8097 weight=2;
}

server{
  listen 80;
  server_name 10.1.10.90;
  
  access_log logs/90.access.log;
  error_log logs/90.error.log;

  large_client_header_buffers 4 16k;     # 读取大型客户端请求头的缓冲区的最大数量和大小
  client_max_body_size 300m;     #设置nginx能处理的最大请求主体大小。
  client_body_buffer_size 128k;  #请求主体的缓冲区大小。 
  proxy_connect_timeout 600;
  proxy_read_timeout 600;
  proxy_send_timeout 600;
  proxy_buffer_size 64k;
  proxy_buffers   4 32k;
  proxy_busy_buffers_size 64k;
  proxy_temp_file_write_size 64k;
 
  location / {
	uwsgi_send_timeout 600;      # 指定向uWSGI传送请求的超时时间，完成握手后向uWSGI传送请求的超时时间。
        uwsgi_connect_timeout 600;   # 指定连接到后端uWSGI的超时时间。
        uwsgi_read_timeout 600;      # 指定接收uWSGI应答的超时时间，完成握手后接收uWSGI应答的超时时间。

        index  index.php  index.html  index.htm;  
	proxy_pass  http://sample; 
        proxy_redirect  default; 
    }
 
}
```

重启后访问`http://10.1.100.90`就会按照1:2:2:2的比例依次分别转发到4台集群服务器对应的访问地址上。

## 特殊链接，只转发到集群服务器的某一台上该如何配置

有时候想要某个链接访问时只被转发到4台集群服务器上的某一台上时，该如何配置呢？

场景如下：有很多的视频只存放在`10.1.100.94`这台服务器上，要想通过访问nginx服务器的统一对外链接来访问到`10.1.100.94`这台服务器的视频，而不是把视频在每个服务器上都放套，那就需要这个对外链接只转发到该服务器上。

好的，开始配置：

1. `10.1.100.94`这台服务器上的视频访问入口为`http://10.1.100.94:8888`
2. nginx服务器的对外统一视频入口为`http://10.1.10.90/video/`
3. 那么只需要在访问`http://10.1.10.90/video/`时nginx将其转发到`http://10.1.100.94:8888`即可
4. 只需要在配置文件中添加如下配置即可：

```
location ^~/video/ {
	proxy_set_header Host $host;
	proxy_set_header  X-Real-IP        $remote_addr;
	proxy_set_header  X-Forwarded-For  $proxy_add_x_forwarded_for;
	proxy_set_header X-NginX-Proxy true;
	proxy_pass http://video/;
}
```

那么`10.1.100.90.conf`的完整配置如下：

```
upstream sample { 
	server 10.1.100.94:8094 weight=1;
	server 10.1.100.95:8095 weight=2;
	server 10.1.100.96:8096 weight=2;
	server 10.1.100.97:8097 weight=2;
}

upstream video { 
	server 10.1.100.94:8888;
}

server{
  listen 80;
  server_name 10.1.10.90;
  
  access_log logs/90.access.log;
  error_log logs/90.error.log;

  large_client_header_buffers 4 16k;     # 读取大型客户端请求头的缓冲区的最大数量和大小
  client_max_body_size 300m;     #设置nginx能处理的最大请求主体大小。
  client_body_buffer_size 128k;  #请求主体的缓冲区大小。 
  proxy_connect_timeout 600;
  proxy_read_timeout 600;
  proxy_send_timeout 600;
  proxy_buffer_size 64k;
  proxy_buffers   4 32k;
  proxy_busy_buffers_size 64k;
  proxy_temp_file_write_size 64k;
 
  location / {
	uwsgi_send_timeout 600;      # 指定向uWSGI传送请求的超时时间，完成握手后向uWSGI传送请求的超时时间。
        uwsgi_connect_timeout 600;   # 指定连接到后端uWSGI的超时时间。
        uwsgi_read_timeout 600;      # 指定接收uWSGI应答的超时时间，完成握手后接收uWSGI应答的超时时间。

        index  index.php  index.html  index.htm;  
	proxy_pass  http://sample; 
        proxy_redirect  default; 
    }
  location ^~/video/ {
        proxy_set_header Host $host;
        proxy_set_header  X-Real-IP        $remote_addr;
        proxy_set_header  X-Forwarded-For  $proxy_add_x_forwarded_for;
        proxy_set_header X-NginX-Proxy true;
        proxy_pass http://video/;
    }
 
 
}
```

总结：使用Nginx做反向代理的时候，可以直接把请求原封不动的转发给下一个服务。设置proxy_pass请求只会替换域名，如果要根据不同的url后缀来访问不同的服务，便可以如此设置。比如访问`http://10.1.10.90/video/`，想要根据url后缀的`/video/`去访问`http://10.1.100.94:8888/`的服务时，上面的方法就完美的实现了这样的需求。并且在`http://10.1.10.90/video/`后面加任何的后缀转发时都会自动拼在`http://10.1.100.94:8888/`后面。

